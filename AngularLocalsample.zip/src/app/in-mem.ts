import { InMemoryDbService } from 'angular-in-memory-web-api';

export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const customers = [
      { id: 1, name: 'HANAR', country: 'France' },
      { id: 2, name: 'VINER', country: 'Brazil'  },
      { id: 3, name: 'JOHN', country: 'Germany'  },
      { id: 4, name: 'TOMSP', country: 'USA'  },
      { id: 5, name: 'SUPRD', country: 'Belgium'  }
    ];
    return {customers};
  }
}
