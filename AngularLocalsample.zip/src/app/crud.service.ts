import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { map } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { Customer } from './customer';
import { DataStateChangeEventArgs, DataSourceChangedEventArgs } from '@syncfusion/ej2-grids';
import { DataManager, Query } from '@syncfusion/ej2-data';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class CrudService extends Subject<DataStateChangeEventArgs>  {

  private customersUrl = 'api/customers';  // URL to web api

  constructor(
    private http: HttpClient) {
    super();
  }

  public execute(state: any): void {
      this.getAllData(state).subscribe(x => super.next(x as DataStateChangeEventArgs));
  }

  private applyGrouping(query: Query, group: any): void {
    // Check if sorting data is available
    if (group.length > 0) {
      // Iterate through each group info
      group.forEach((column: string) => {
        // perform group operation using the column on the query
        query.group(column);
      });
    }
  }

  private applyPaging(query: Query, state: any) {
    // Check if both 'take' and 'skip' values are available
    if (state.take && state.skip) {
      // Calculate pageSkip and pageTake values to get pageIndex and pageSize
      const pageSkip = state.skip / state.take + 1;
      const pageTake = state.take;
      query.page(pageSkip, pageTake);
    }
    // If if only 'take' is available and 'skip' is 0, apply paging for the first page.
    else if (state.skip === 0 && state.take) {
      query.page(1, state.take);
    }
  }

  /** GET all data from the server */
  getAllData( state ?: any): Observable<any> {
    const query = new Query();

    if (state.group) {
      state.group.length ? this.applyGrouping(query, state.group) :
        // initial grouping
        state.group.columns.length ? this.applyGrouping(query, state.group.columns) : null
    }

     // paging
     this.applyPaging(query, state)
     // To get the count of the data
     query.isCountRequired = true;

     return this.http.get<Customer[]>(this.customersUrl).pipe(
      map((response: any[]) => {
        // console.log('response => ', response);
        // Execute local data operations using the provided query
        const currentResult: any = new DataManager(response).executeLocal(query);
        console.log('pipe => ', currentResult);
        // Return the result along with the count of total records
        return {
          result: (currentResult as any).result, // Result of the data
          count: (currentResult as any).count // Total record count
        };
      })
    );

    // return this.http.get<Customer[]>(this.customersUrl)
    //   .map((response: any) => (<any>{
    //     result: state.take > 0 ? response.slice(0, state.take) : response,
    //     count: response.length
    //   }))
    //   .map((data: any) => data);
  }

  /** POST: add a new record  to the server */
  addRecord(state: DataSourceChangedEventArgs): Observable<Customer> {
    // you can apply empty string instead of state.data to get failure(error)
    return this.http.post<Customer>(this.customersUrl, state.data, httpOptions);
  }

  /** DELETE: delete the record from the server */
  deleteRecord(state: any): Observable<Customer> {
    const id = state.data[0].id;
    const url = `${this.customersUrl}/${id}`;

    return this.http.delete<Customer>(url, httpOptions);
  }

  /** PUT: update the record on the server */
  updateRecord(state: DataSourceChangedEventArgs): Observable<any> {
    return this.http.put(this.customersUrl, state.data, httpOptions);
  }

}

