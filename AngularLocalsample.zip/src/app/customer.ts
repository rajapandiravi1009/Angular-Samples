export class Customer {
    id: any;
    name: any;
    country: any;
  }
