import { Component, OnInit, ViewChild, ViewContainerRef, Inject } from '@angular/core';
import { GridComponent, ToolbarItems, ToolbarService, ExcelExportService } from '@syncfusion/ej2-angular-grids';
import { data, employeeData } from './dataSource';
import { Observable } from 'rxjs/Observable';
import { CrudService } from './crud.service';
import { Customer } from './customer';
import { DataStateChangeEventArgs, Sorts, DataSourceChangedEventArgs } from '@syncfusion/ej2-grids';
import { QueryCellInfoEventArgs } from '@syncfusion/ej2-angular-grids';
import { Tooltip } from '@syncfusion/ej2-popups';
import { OrdersService } from './order.service';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  public data: Observable<DataStateChangeEventArgs>;
    public fields: Object = { text:'country', value: 'country' };
    public editSettings: any;
    public groupOptions: any;
    public toolbar: any;
    public state: any;
    @ViewChild('grid')
    public grid: any;
    customers: any;
    constructor(private crudService: CrudService, private http: HttpClient) {
        this.data = crudService;
    }

    public dataStateChange(state: DataStateChangeEventArgs): void {
        this.crudService.execute(state);
    }

    public selected(args: any): void {
      if(args.selectedItem.innerText.toLowerCase() === 'metrics') {
        setTimeout(() => {
          if (this.grid.groupSettings.columns.length) {
            const state: any = { skip: 0, take: 12, group: this.groupOptions };
            this.crudService.execute(state);
          }
          else {
            const state: any = { skip: 0, take: 12 };
            this.crudService.execute(state);
          }
        })
          
        
        
      }
    }

    public dataSourceChanged(state: DataSourceChangedEventArgs): void {
        if (state.action === 'add') {
            this.crudService.addRecord(state).subscribe(() => {
                (state as any).endEdit()
            });
            this.crudService.addRecord(state).subscribe(() => { }, error => console.log(error), () => {
              (state as any).endEdit()
            });
        } else if (state.action === 'edit') {
            this.crudService.updateRecord(state).subscribe(() => {
              (state as any).endEdit()
            }, (e) => {
                this.grid.closeEdit();
            }
            );
        } else if (state.requestType === 'delete') {
            this.crudService.deleteRecord(state).subscribe(() => {
              (state as any).endEdit()
            });
        }
    }

    public ngOnInit(): void {
        this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal' };
        this.groupOptions = { columns: ['name'], showGroupedColumn: true, };
        this.toolbar = ['Add', 'Edit', 'Delete', 'Update', 'Cancel'];
        
        const state: any = { skip: 0, take: 12, group:this.groupOptions };
        this.crudService.execute(state);
    }
}
