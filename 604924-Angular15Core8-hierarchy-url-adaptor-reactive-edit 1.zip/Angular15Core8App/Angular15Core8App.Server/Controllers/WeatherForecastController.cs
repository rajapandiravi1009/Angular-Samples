using Microsoft.AspNetCore.Mvc;
using Syncfusion.EJ2.Base;
using System.Collections;

namespace Angular15Core8App.Server.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }

    [ApiController]
    [Route("[controller]")]
    public class HomeController : ControllerBase
    {
        public static List<OrdersDetails> orddata = OrdersDetails.GetAllRecords();
        public static List<EmployeeView> empdata = EmployeeView.GetAllRecords();
        public static List<Customer> customerdata = Customer.GetAllRecords();
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        [HttpPost("GridParentDataOperationHandler")]
        public IActionResult GridParentDataOperationHandler([FromBody] DataManagerRequest dm)
        {
            IEnumerable DataSource = empdata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            int count = DataSource.Cast<EmployeeView>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);    //Paging
            }
            return dm.RequiresCounts ? new JsonResult(new { result = DataSource, count = count }) : new JsonResult(DataSource);
        }
        [HttpPost("GridChildDataOperationHandler")]
        public IActionResult GridChildDataOperationHandler([FromBody] DataManagerRequest dm)
        {
            IEnumerable DataSource = orddata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            int count = DataSource.Cast<OrdersDetails>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);    //Paging
            }
            return dm.RequiresCounts ? new JsonResult(new { result = DataSource, count = count }) : new JsonResult(DataSource);
        }
        [HttpPost("GridSecondChildDataOperationHandler")]
        public IActionResult GridSecondChildDataOperationHandler([FromBody] DataManagerRequest dm)
        {
            IEnumerable DataSource = customerdata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            int count = DataSource.Cast<Customer>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);    //Paging
            }
            return dm.RequiresCounts ? new JsonResult(new { result = DataSource, count = count }) : new JsonResult(DataSource);
        }
        [HttpPost("GridInsertPostHandler")]
        public IActionResult GridInsertPostHandler([FromBody] CRUDModel<OrdersDetails> value)
        {
            HomeController.orddata.Insert(0, value.Value);
            return new JsonResult(value);
        }
        [HttpPost("GridUpdatePostHandler")]
        public IActionResult GridUpdatePostHandler([FromBody] CRUDModel<OrdersDetails> value)
        {
            var data = HomeController.orddata.Where(or => or.OrderID == value.Value.OrderID).FirstOrDefault();
            if (data != null)
            {
                data.OrderID = value.Value.OrderID;
                data.CustomerID = value.Value.CustomerID;
                data.Freight = value.Value.Freight;
                data.EmployeeID = value.Value.EmployeeID;
                data.ShipCity = value.Value.ShipCity;
                data.Verified = value.Value.Verified;
                data.OrderDate = value.Value.OrderDate;
                data.ShipName = value.Value.ShipName;
                data.ShipCountry = value.Value.ShipCountry;
                data.ShippedDate = value.Value.ShippedDate;
                data.ShipAddress = value.Value.ShipAddress;
            }
            return new JsonResult(value);
        }
        [HttpPost("GridRemovePostHandler")]
        public IActionResult GridRemovePostHandler([FromBody] CRUDModel<OrdersDetails> value)
        {
            HomeController.orddata.Remove(HomeController.orddata.Where(or => or.OrderID == int.Parse(value.Key.ToString())).FirstOrDefault());
            return new JsonResult(value);
        }
        [HttpPost("GridCrudPostHandler")]
        public IActionResult GridCrudPostHandler([FromBody] CRUDModel<OrdersDetails> value)
        {
            if (value.Action == "update")
            {
                var data = HomeController.orddata.Where(or => or.OrderID == value.Value.OrderID).FirstOrDefault();
                if (data != null)
                {
                    data.OrderID = value.Value.OrderID;
                    data.CustomerID = value.Value.CustomerID;
                    data.Freight = value.Value.Freight;
                    data.EmployeeID = value.Value.EmployeeID;
                    data.ShipCity = value.Value.ShipCity;
                    data.Verified = value.Value.Verified;
                    data.OrderDate = value.Value.OrderDate;
                    data.ShipName = value.Value.ShipName;
                    data.ShipCountry = value.Value.ShipCountry;
                    data.ShippedDate = value.Value.ShippedDate;
                    data.ShipAddress = value.Value.ShipAddress;
                }
            }
            else if (value.Action == "insert")
            {
                HomeController.orddata.Insert(0, value.Value);
            }
            else if (value.Action == "remove")
            {

                HomeController.orddata.Remove(HomeController.orddata.Where(or => or.OrderID == (Int64)value.Key).FirstOrDefault());
            }
            return new JsonResult(value);
        }
    }

    [ApiController]
    [Route("[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly ILogger<OrdersController> _logger;

        public OrdersController(ILogger<OrdersController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetOrders")]
        public IEnumerable<OrdersDetails> Get()
        {
            return OrdersDetails.GetAllRecords().ToArray();
        }
    }
    public class OrdersDetails
    {
        public OrdersDetails()
        {

        }
        public OrdersDetails(int OrderID, string CustomerId, int EmployeeId, double Freight, bool Verified, DateTime OrderDate, string ShipCity, string ShipName, string ShipCountry, DateTime ShippedDate, string ShipAddress)
        {
            this.OrderID = OrderID;
            this.CustomerID = CustomerId;
            this.EmployeeID = EmployeeId;
            this.Freight = Freight;
            this.ShipCity = ShipCity;
            this.Verified = Verified;
            this.OrderDate = OrderDate;
            this.ShipName = ShipName;
            this.ShipCountry = ShipCountry;
            this.ShippedDate = ShippedDate;
            this.ShipAddress = ShipAddress;
        }
        public static List<OrdersDetails> GetAllRecords()
        {
            List<OrdersDetails> order = new List<OrdersDetails>();
            int code = 10000;
            for (int i = 1; i <= 1000; i++)
            {
                order.Add(new OrdersDetails(code + 1, "ALFKI", i + 0, 2.3 * i, false, new DateTime(1991, 05, 15, 10, 40, 00), "Berlin", "Simons bistro", "Denmark", new DateTime(1996, 7, 16), "Kirchgasse 6"));
                order.Add(new OrdersDetails(code + 2, "ANATR", i + 2, 3.3 * i, true, new DateTime(1990, 04, 04, 09, 30, 00), "Madrid", "Queen Cozinha", "Brazil", new DateTime(1996, 9, 11), "Avda. Azteca 123"));
                order.Add(new OrdersDetails(code + 3, "ANTON", i + 1, 4.3 * i, true, new DateTime(1957, 11, 30, 03, 45, 00), "Cholchester", "Frankenversand", "Germany", new DateTime(1996, 10, 7), "Carrera 52 con Ave. Bol�var #65-98 Llano Largo"));
                order.Add(new OrdersDetails(code + 4, "BLONP", i + 3, 5.3 * i, false, new DateTime(1930, 10, 22, 07, 30, 00), "Marseille", "Ernst Handel", "Austria", new DateTime(1996, 12, 30), "Magazinweg 7"));
                order.Add(new OrdersDetails(code + 5, "BOLID", i + 4, 6.3 * i, true, new DateTime(1953, 02, 18, 05, 50, 00), "Tsawassen", "Hanari Carnes", "Switzerland", new DateTime(1997, 12, 3), "1029 - 12th Ave. S."));
                code += 5;
            }
            return order;
        }

        public static List<OrdersDetails> GetRecords()
        {
            List<OrdersDetails> orders = new List<OrdersDetails>();
            int code = 10000;
            for (int i = 1; i < 120; i++)
            {
                orders.Add(new OrdersDetails(code + 1, "ALFKI", i + 0, 2.3 * i, false, new DateTime(1991, 05, 15, 10, 40, 00), "Berlin", "Simons bistro", "Denmark", new DateTime(1996, 7, 16, 09, 30, 00), "Kirchgasse 6"));
                orders.Add(new OrdersDetails(code + 2, "ANATR", i + 2, 3.3 * i, true, new DateTime(1990, 04, 04, 09, 30, 00), "Madrid", "Queen Cozinha", "Brazil", new DateTime(1996, 9, 11, 03, 45, 00), "Avda. Azteca 123"));
                orders.Add(new OrdersDetails(code + 3, "ANTON", i + 1, 4.3 * i, true, new DateTime(1957, 11, 30, 03, 45, 00), "Cholchester", "Frankenversand", "Germany", new DateTime(1996, 10, 7, 07, 50, 00), "Carrera 52 con Ave. Bol�var #65-98 Llano Largo"));
                orders.Add(new OrdersDetails(code + 4, "BLONP", i + 3, 5.3 * i, false, new DateTime(1930, 10, 22, 07, 30, 00), "Marseille", "Ernst Handel", "Austria", new DateTime(1996, 12, 30, 06, 12, 00), "Magazinweg 7"));
                orders.Add(new OrdersDetails(code + 5, "BOLID", i + 4, 6.3 * i, true, new DateTime(1953, 02, 18, 05, 50, 00), "Tsawassen", "Hanari Carnes", "Switzerland", new DateTime(1997, 12, 3, 12, 50, 00), "1029 - 12th Ave. S."));
                code += 5;
            }
            return orders;
        }

        public int? OrderID { get; set; }
        public string CustomerID { get; set; }
        public int? EmployeeID { get; set; }
        public double? Freight { get; set; }
        public string ShipCity { get; set; }
        public bool Verified { get; set; }
        public DateTime OrderDate { get; set; }

        public string ShipName { get; set; }

        public string ShipCountry { get; set; }

        public DateTime ShippedDate { get; set; }
        public string ShipAddress { get; set; }
    }

    public class Customer
    {
        public Customer() { }
        public Customer(string CustomerID, string ContactName, string CompanyName, string Address, string Country)
        {
            this.CustomerID = CustomerID;
            this.CompanyName = CompanyName;
            this.ContactName = ContactName;
            this.Address = Address;
            this.Country = Country;

        }
        public static List<Customer> GetAllRecords()
        {
            List<Customer> cust = new List<Customer>();
            cust.Add(new Customer("ALFKI", "Maria ", "Alfreds Futterkiste", "Obere Str. 57", "Germany"));
            cust.Add(new Customer("ANATR", "Ana Trujillo", "Ana Trujillo Emparedados y helados", "Avda. de la Constituci�n 2222", "Mexico"));
            cust.Add(new Customer("BLONP", "Fr�d�rique Citeaux", "Blondesddsl p�re et fils", "24, place Kl�ber", "France"));
            cust.Add(new Customer("BOLID", "Mart�n Sommer", "B�lido Comidas preparadas", "C/ Araquil, 67", "Spain"));
            cust.Add(new Customer("ANTON", "Elizabeth Lincoln", "Bottom-Dollar Markets", "23 Tsawassen Blvd.", "Canada"));
            // cust.Add(new Customer("BONAP", "Laurence Lebihan", "Bon app", "12, rue des Bouchers", "France"));           
            // cust.Add(new Customer("BSBEV", "Victoria Ashworth", "B's Beverages", "Fauntleroy Circus", "UK"));
            // cust.Add(new Customer("CACTU", "Patricio Simpson", "Cactus Comidas para llevar", "Cerrito 333", "Argentina"));
            // cust.Add(new Customer("CENTC", "Francisco Chang", "Centro comercial Moctezuma", "Sierras de Granada 9993", "Mexico"));
            // cust.Add(new Customer("CHOPS", "Yang Wang", "Chop-suey Chinese", "Hauptstr. 29", "Switzerland"));
            // cust.Add(new Customer("COMMI", "Pedro Afonso", "Com�rcio Mineiro", "Av. dos Lus�adas, 23", "Brazil"));
            // cust.Add(new Customer("CONSH", "Elizabeth Brown", "Consolidated Holdings", "Berkeley Gardens 12  Brewery", "UK"));
            // cust.Add(new Customer("DRACD", "Sven Ottlieb", "Drachenblut Delikatessen", "Walserweg 21", "Germany"));
            // cust.Add(new Customer("DUMON", "Janine Labrune", "Du monde entier", "67, rue des Cinquante Otages", "France"));
            // cust.Add(new Customer("EASTC", "Ann Devon", "Eastern Connection", "35 King George", "UK"));
            // cust.Add(new Customer("ERNSH", "Roland Mendel", "Ernst Handel", "Kirchgasse 6", "Austria"));
            // cust.Add(new Customer("FAMIA", "Aria Cruz", "Familia Arquibaldo", "Rua Or�s, 92", "Brazil"));
            // cust.Add(new Customer("FISSA", "Diego Roel", "FISSA Fabrica Inter. Salchichas S.A.", "C/ Moralzarzal, 86", "Spain"));
            // cust.Add(new Customer("FOLIG", "Martine Ranc�", "Folies gourmandes", "184, chauss�e de Tournai", "France"));
            // cust.Add(new Customer("FOLKO", "Maria Larsson", "Folk och f� HB", "�kergatan 24", "Sweden"));
            // cust.Add(new Customer("FRANK", "Peter Franken", "Frankenversand", "Berliner Platz 43", "Germany"));
            // cust.Add(new Customer("FRANR", "Carine Schmitt", "France restauration", "54, rue Royale", "France"));
            // cust.Add(new Customer("FRANS", "Paolo Accorti", "Franchi S.p.A.", "Via Monte Bianco 34", "Italy"));
            // cust.Add(new Customer("FURIB", "Lino Rodriguez", "Furia Bacalhau e Frutos do Mar", "Jardim das rosas n. 32", "Portugal"));
            // cust.Add(new Customer("GALED", "Eduardo Saavedra", "Galer�a del gastr�nomo", "Rambla de Catalu�a, 23", "Spain"));
            // cust.Add(new Customer("GODOS", "Jos� Pedro Freyre", "Godos Cocina T�pica", "C/ Romero, 33", "Spain"));
            // cust.Add(new Customer("GOURL", "Andr� Fonseca", "Gourmet Lanchonetes", "Av. Brasil, 442", "Brazil"));
            // cust.Add(new Customer("GREAL", "Howard Snyder", "Great Lakes Food Market", "2732 Baker Blvd.", "USA"));
            // cust.Add(new Customer("GROSR", "Manuel Pereira", "GROSELLA-Restaurante", "5� Ave. Los Palos Grandes", "Venezuela"));
            // cust.Add(new Customer("HANAR", "Mario Pontes", "Hanari Carnes", "Rua do Pa�o, 67", "Brazil"));
            // cust.Add(new Customer("HILAA", "Carlos Hern�ndez", "HILARION-Abastos", "Carrera 22 con Ave. Carlos Soublette #8-35", "Venezuela"));
            // cust.Add(new Customer("HUNGC", "Yoshi Latimer", "Hungry Coyote Import Store", "City Center Plaza 516 Main St.", "USA"));
            // cust.Add(new Customer("HUNGO", "Patricia McKenna", "Hungry Owl All-Night Grocers", "8 Johnstown Road", "Ireland"));
            // cust.Add(new Customer("ISLAT", "Helen Bennett", "Island Trading", "Garden House Crowther Way", "UK"));
            // cust.Add(new Customer("KOENE", "Philip Cramer", "K�niglich Essen", "Maubelstr. 90", "Germany"));
            // cust.Add(new Customer("LACOR", "Daniel Tonini", "La corne d'abondance", "67, avenue de l'Europe", "France"));
            // cust.Add(new Customer("LAMAI", "Annette Roulet", "La maison d'Asie", "1 rue Alsace-Lorraine", "France"));
            // cust.Add(new Customer("LAUGB", "Yoshi Tannamuri", "Laughing Bacchus Wine Cellars", "1900 Oak St.", "Canada"));
            // cust.Add(new Customer("LAZYK", "John Steel", "Lazy K Kountry Store", "12 Orchestra Terrace", "USA"));
            // cust.Add(new Customer("LEHMS", "Renate Messner", "Lehmanns Marktstand", "Magazinweg 7", "Germany"));
            // cust.Add(new Customer("LETSS", "Jaime Yorres", "Let's Stop N Shop", "87 Polk St. Suite 5", "USA"));
            // cust.Add(new Customer("LILAS", "Carlos Gonz�lez", "LILA-Supermercado", "Carrera 52 con Ave. Bol�var #65-98 Llano Largo", "Venezuela"));
            // cust.Add(new Customer("LINOD", "Felipe Izquierdo", "LINO-Delicateses", "Ave. 5 de Mayo Porlamar", "Venezuela"));
            // cust.Add(new Customer("LONEP", "Fran Wilson", "Lonesome Pine Restaurant", "89 Chiaroscuro Rd.", "USA"));
            // cust.Add(new Customer("MAGAA", "Giovanni Rovelli", "Magazzini Alimentari Riuniti", "Via Ludovico il Moro 22", "Italy"));
            // cust.Add(new Customer("MAISD", "Catherine Dewey", "Maison Dewey", "Rue Joseph-Bens 532", "Belgium"));
            // cust.Add(new Customer("MEREP", "Jean Fresni�re", "M�re Paillarde", "43 rue St. Laurent", "Canada"));
            // cust.Add(new Customer("MORGK", "Alexander Feuer", "Morgenstern Gesundkost", "Heerstr. 22", "Germany"));
            // cust.Add(new Customer("NORTS", "Simon Crowther", "North/South", "South House 300 Queensbridge", "UK"));
            // cust.Add(new Customer("OCEAN", "Yvonne Moncada", "Oc�ano Atl�ntico Ltda.", "Ing. Gustavo Moncada 8585 Piso 20-A", "Argentina"));
            // cust.Add(new Customer("OLDWO", "Rene Phillips", "Old World Delicatessen", "2743 Bering St.", "USA"));
            // cust.Add(new Customer("OTTIK", "Henriette Pfalzheim", "Ottilies K�seladen", "Mehrheimerstr. 369", "Germany"));
            // cust.Add(new Customer("PARIS", "Marie Bertrand", "Paris sp�cialit�s", "265, boulevard Charonne", "France"));
            // cust.Add(new Customer("PERIC", "Guillermo Fern�ndez", "Pericles Comidas cl�sicas", "Calle Dr. Jorge Cash 321", "Mexico"));
            // cust.Add(new Customer("PICCO", "Georg Pipps", "Piccolo und mehr", "Geislweg 14", "Austria"));
            // cust.Add(new Customer("PRINI", "Isabel de Castro", "Princesa Isabel Vinhos", "Estrada da sa�de n. 58", "Portugal"));
            // cust.Add(new Customer("QUEDE", "Bernardo Batista", "Que Del�cia", "Rua da Panificadora, 12", "Brazil"));
            // cust.Add(new Customer("QUEEN", "L�cia Carvalho", "Queen Cozinha", "Alameda dos Can�rios, 891", "Brazil"));
            // cust.Add(new Customer("QUICK", "Horst Kloss", "QUICK-Stop", "Taucherstra�e 10", "Germany"));
            // cust.Add(new Customer("RANCH", "Sergio Guti�rrez", "Rancho grande", "Av. del Libertador 900", "Argentina"));
            // cust.Add(new Customer("RATTC", "Paula Wilson", "Rattlesnake Canyon Grocery", "2817 Milton Dr.", "USA"));
            // cust.Add(new Customer("REGGC", "Maurizio Moroni", "Reggiani Caseifici", "Strada Provinciale 124", "Italy"));
            // cust.Add(new Customer("RICAR", "Janete Limeira", "Ricardo Adocicados", "Av. Copacabana, 267", "Brazil"));
            // cust.Add(new Customer("RICSU", "Michael Holz", "Richter Supermarkt", "Grenzacherweg 237", "Switzerland"));
            // cust.Add(new Customer("ROMEY", "Alejandra Camino", "Romero y tomillo", "Gran V�a, 1", "Spain"));
            // cust.Add(new Customer("SANTG", "Jonas Bergulfsen", "Sant� Gourmet", "Erling Skakkes gate 78", "Norway"));
            // cust.Add(new Customer("SAVEA", "Jose Pavarotti", "Save-a-lot Markets", "187 Suffolk Ln.", "USA"));
            // cust.Add(new Customer("SEVES", "Hari Kumar", "Seven Seas Imports", "90 Wadhurst Rd.", "UK"));
            // cust.Add(new Customer("SIMOB", "Jytte Petersen", "Simons bistro", "Vinb�ltet 34", "Denmark"));
            // cust.Add(new Customer("SPECD", "Dominique Perrier", "Sp�cialit�s du monde", "25, rue Lauriston", "France"));
            // cust.Add(new Customer("SPLIR", "Art Braunschweiger", "Split Rail Beer & Ale", "P.O. Box 555", "USA"));
            // cust.Add(new Customer("SUPRD", "Pascale Cartrain", "Supr�mes d�lices", "Boulevard Tirou, 255", "Belgium"));
            // cust.Add(new Customer("THEBI", "Liz Nixon", "The Big Cheese", "89 Jefferson Way Suite 2", "USA"));
            // cust.Add(new Customer("THECR", "Liu Wong", "The Cracker Box", "55 Grizzly Peak Rd.", "USA"));
            // cust.Add(new Customer("TOMSP", "Karin Josephs", "Toms Spezialit�ten", "Luisenstr. 48", "Germany"));
            // cust.Add(new Customer("TORTU", "Miguel Angel Paolino", "Tortuga Restaurante", "Avda. Azteca 123", "Mexico"));
            // cust.Add(new Customer("TRADH", "Anabela Domingues", "Tradi��o Hipermercados", "Av. In�s de Castro, 414", "Brazil"));
            // cust.Add(new Customer("TRAIH", "Helvetius Nagy", "Trail's Head Gourmet Provisioners", "722 DaVinci Blvd.", "USA"));
            // cust.Add(new Customer("VAFFE", "Palle Ibsen", "Vaffeljernet", "Smagsloget 45", "Denmark"));
            // cust.Add(new Customer("VICTE", "Mary Saveley", "Victuailles en stock", "2, rue du Commerce", "France"));
            // cust.Add(new Customer("VINET", "Paul Henriot", "Vins et alcools Chevalier", "59 rue de l'Abbaye", "France"));
            // cust.Add(new Customer("WANDK", "Rita M�ller", "Die Wandernde Kuh", "Adenauerallee 900", "Germany"));
            // cust.Add(new Customer("WARTH", "Pirkko Koskitalo", "Wartian Herkku", "Torikatu 38", "Finland"));
            // cust.Add(new Customer("WELLI", "Paula Parente", "Wellington Importadora", "Rua do Mercado, 12", "Brazil"));
            // cust.Add(new Customer("WHITC", "Karl Jablonski", "White Clover Markets", "305 - 14th Ave. S. Suite 3B", "USA"));
            // cust.Add(new Customer("WILMK", "Matti Karttunen", "Wilman Kala", "Keskuskatu 45", "Finland"));
            // cust.Add(new Customer("WOLZA", "Zbyszek Piestrzeniewicz", "Wolski  Zajazd", "ul. Filtrowa 68", "Poland"));
            return cust;
        }
        public string CustomerID { get; set; }
        public string ContactName { get; set; }
        public string CompanyName { get; set; }
        public string Address { get; set; }
        public string Country { get; set; }
    }

    public class EmployeeView
    {
        public EmployeeView()
        {

        }
        public EmployeeView(int EmployeeID, string FirstName, string LastName, string Title, DateTime BirthDate, DateTime HireDate, int ReportsTo, string Address, string PostalCode, string Phone, string City, string Country)
        {
            this.EmployeeID = EmployeeID;
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Title = Title;
            this.BirthDate = BirthDate;
            this.HireDate = HireDate;
            this.ReportsTo = ReportsTo;
            this.Address = Address;
            this.PostalCode = PostalCode;
            this.Phone = Phone;
            this.City = City;
            this.Country = Country;

        }
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public DateTime BirthDate { get; set; }
        public DateTime HireDate { get; set; }

        public int ReportsTo { get; set; }

        public string Address { get; set; }
        public string PostalCode { get; set; }
        public string Phone { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public static List<EmployeeView> GetAllRecords()
        {
            List<EmployeeView> Emp = new List<EmployeeView>();
            Emp.Add(new EmployeeView(1, "Nancy", "Davolio", "Sales Representative", new DateTime(1948, 12, 08), new DateTime(1992, 05, 01), 2, "507 - 20th Ave. E.Apt. 2A ", " 98122", "(206) 555-9857 ", "Seattle ", "USA"));
            Emp.Add(new EmployeeView(2, "Andrew", "Fuller", "Vice President, Sales", new DateTime(1952, 02, 19), new DateTime(1992, 08, 14), 4, "908 W. Capital Way", "98401 ", "(206) 555-9482 ", "Kirkland ", "USA"));
            Emp.Add(new EmployeeView(3, "Janet", "Leverling", "Sales Representative", new DateTime(1963, 08, 30), new DateTime(1992, 04, 01), 3, " 4110 Old Redmond Rd.", "98052 ", "(206) 555-8122", "Redmond ", "USA "));
            Emp.Add(new EmployeeView(4, "Margaret", "Peacock", "Sales Representative", new DateTime(1937, 09, 19), new DateTime(1993, 05, 03), 6, "14 Garrett Hill ", "SW1 8JR ", "(71) 555-4848 ", "London ", "UK "));
            Emp.Add(new EmployeeView(5, "Steven", "Buchanan", "Sales Manager", new DateTime(1955, 03, 04), new DateTime(1993, 10, 17), 8, "Coventry HouseMiner Rd. ", "EC2 7JR ", " (206) 555-8122", "Tacoma ", " USA"));
            Emp.Add(new EmployeeView(6, "Michael", "Suyama", "Sales Representative", new DateTime(1963, 07, 02), new DateTime(1993, 10, 17), 2, " 7 Houndstooth Rd.", " WG2 7LT", "(71) 555-4444 ", "London ", "UK "));
            Emp.Add(new EmployeeView(7, "Robert", "King", "Sales Representative", new DateTime(1960, 05, 29), new DateTime(1994, 01, 02), 7, "Edgeham HollowWinchester Way ", "RG1 9SP ", "(71) 555-5598 ", "London ", " UK"));
            Emp.Add(new EmployeeView(8, "Laura", "Callahan", "Inside Sales Coordinator", new DateTime(1958, 01, 09), new DateTime(1994, 03, 05), 9, "722 Moss Bay Blvd. ", "98033 ", " (206) 555-3412", "Seattle ", "USA "));
            Emp.Add(new EmployeeView(9, "Anne", "Dodsworth", "Sales Representative", new DateTime(1966, 01, 27), new DateTime(1994, 11, 15), 5, "4726 - 11th Ave. N.E. ", "98105 ", "(71) 555-5598 ", " London", "UK "));
            return Emp;
        }
    }
}
