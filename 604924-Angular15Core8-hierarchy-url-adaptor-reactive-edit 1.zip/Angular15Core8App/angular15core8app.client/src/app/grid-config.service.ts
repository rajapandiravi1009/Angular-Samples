import { Injectable, TemplateRef } from '@angular/core';
import { Column, ColumnModel, EditSettingsModel } from '@syncfusion/ej2-angular-grids';
// import { customerData, employeeData, orderData, orderDatas } from './data';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DataManager, DataUtil, UrlAdaptor } from '@syncfusion/ej2-data';

@Injectable({
  providedIn: 'root',
})
export class GridConfigService {
  getEditSettings(template: any): EditSettingsModel {
    return {
      mode: 'Dialog',
      allowEditing: true,
      template: template,
    };
  }
  getParentGridData() {
    // return employeeData; // local data
    return new DataManager({
      url: 'https://localhost:7085/Home/GridParentDataOperationHandler',
      adaptor: new UrlAdaptor()
    });
  }

  getParentGridColumns(): Column[] | string[] | ColumnModel[] {
    return [
      {
        field: 'EmployeeID',
        headerText: 'Employee ID',
        textAlign: 'Right',
        width: 120,
        isPrimaryKey: true,
      },
      {
        field: 'FirstName',
        headerText: 'First Name',
        width: 150,
        validationRules: { required: true },
      },
      {
        field: 'Title',
        headerText: 'Title',
        textAlign: 'Right',
        width: 120,
        format: 'C2',
      },
      { field: 'HireDate', headerText: 'Hire Date', width: 150, format: 'yMd' },
      { field: 'ReportsTo', headerText: 'Reports To', width: 150 },
    ];
  }

  getFirstLevelChildData() {
    // return DataUtil.parse.parseJson(orderDatas); // local data
    return new DataManager({
      url: 'https://localhost:7085/Home/GridChildDataOperationHandler',
      adaptor: new UrlAdaptor()
    });
  }

  getFirstLevelChildColumns(): Column[] | string[] | ColumnModel[] {
    return [
      {
        field: 'OrderID',
        headerText: 'Order ID',
        textAlign: 'Right',
        width: 120,
        isPrimaryKey: true,
      },
      {
        field: 'ShipCity',
        headerText: 'Ship City',
        width: 120,
        validationRules: { required: true },
      },
      { field: 'Freight', headerText: 'Freight', width: 120 },
      {
        field: 'OrderDate',
        headerText: 'OrderDate',
        width: 150,
        format: 'yMd',
        type: 'date',
      },
    ];
  }

  getSecondLevelChildData() {
    // return customerData; // local data
    return new DataManager({
      url: 'https://localhost:7085/Home/GridSecondChildDataOperationHandler',
      adaptor: new UrlAdaptor()
    });
  }

  getSecondLevelChildColumns(): Column[] | string[] | ColumnModel[] {
    return [
      {
        field: 'CustomerID',
        headerText: 'Customer ID',
        textAlign: 'Right',
        width: 75,
        isPrimaryKey: true,
      },
      {
        field: 'ContactName',
        headerText: 'Contact Name',
        width: 100,
        validationRules: { required: true },
      },
      { field: 'Address', headerText: 'Address', width: 120 },
      { field: 'Country', headerText: 'Country', width: 100 },
    ];
  }

  initializeParentForm(data1: any): FormGroup {
    return new FormGroup({
      EmployeeID: new FormControl(data1.EmployeeID, Validators.required),
      FirstName: new FormControl(data1.FirstName, Validators.required),
      Title: new FormControl(data1.Title),
      HireDate: new FormControl(data1.HireDate),
      ReportsTo: new FormControl(data1.ReportsTo),
    });
  }

  initializeFirstLevelChildForm(data1: any): FormGroup {
    return new FormGroup({
      OrderID: new FormControl(data1.OrderID, Validators.required),
      ShipCity: new FormControl(data1.ShipCity, Validators.required),
      Freight: new FormControl(data1.Freight),
      OrderDate: new FormControl(data1.OrderDate),
    });
  }

  initializeSecondLevelChildForm(data1: any): FormGroup {
    return new FormGroup({
      CustomerID: new FormControl(data1.CustomerID, Validators.required),
      ContactName: new FormControl(data1.ContactName, Validators.required),
      Address: new FormControl(data1.Address),
      Country: new FormControl(data1.Country),
    });
  }
}
