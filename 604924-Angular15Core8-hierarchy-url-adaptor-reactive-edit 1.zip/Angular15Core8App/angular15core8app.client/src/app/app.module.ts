import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

// import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GridModule } from '@syncfusion/ej2-angular-grids';
import { DropDownListModule } from '@syncfusion/ej2-angular-dropdowns';
import { NumericTextBoxAllModule, TextAreaAllModule, TextAreaModule } from '@syncfusion/ej2-angular-inputs';
import { DatePickerAllModule } from '@syncfusion/ej2-angular-calendars';
import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SharedGridComponent } from './shared-grid.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    SharedGridComponent,
  ],
  imports: [
    BrowserModule,
        HttpClientModule,
        ReactiveFormsModule,
        FormsModule,
        CommonModule,
        GridModule,
        DropDownListModule,
        NumericTextBoxAllModule,
        TextAreaAllModule,
    DatePickerAllModule,
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RichTextEditorAllModule,
    // AppRoutingModule,
    // SharedGridComponent
    // NgxSpinnerModule,
    // BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

