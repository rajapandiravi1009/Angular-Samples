import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { DataSourceChangedEventArgs, DataStateChangeEventArgs } from "@syncfusion/ej2-angular-grids";
import { DataManager, DataUtil, Query } from "@syncfusion/ej2-data";
import { Observable, Subject, map } from "rxjs";

interface sortInfo {
    name: string
    field: string
    direction: string
}
class OrderDetails {
    OrderID?: number;
    CustomerID?: string;
    EmployeeID?: number;
    Freight?: number;
    ShipCity?: string;
    Verified?: boolean;
    OrderDate?: Date;
    ShipName?: string;
    ShipCountry?: string;
    ShippedDate?: Date;
    ShipAddress?: string;
}

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class CrudService extends Subject<DataStateChangeEventArgs> {
    private ordersUrl = '/orders';  // URL to web api

    constructor(
        private http: HttpClient) {
        super();
    }

    public execute(state: any, query?: any): void {
        this.getAllData(state, query).subscribe(x => {
            console.log('subscribe => ', x);
            if (state.action && state.action.requestType == 'filterchoicerequest' ||
                state.action && state.action.requestType == 'filterSearchBegin' ||
                state.action && state.action.requestType == 'stringfilterrequest') {
                return;
            }
            super.next(x as DataStateChangeEventArgs)
        });
    }

    private applyFiltering(query: Query, filter: any): void {
        // Check if filter columns are specified
        if (filter.columns && filter.columns.length) {
            // Apply filtering for each specified column
            for (let i = 0; i < filter.columns.length; i++) {
                const field = filter.columns[i].field;
                const operator = filter.columns[i].operator;
                const value = filter.columns[i].value;
                query.where(field, operator, value);
            }
        }
        else {
            // Apply filtering based on direct filter conditions
            for (let i = 0; i < filter.length; i++) {
                const { fn, e } = filter[i];
                if (fn === 'onWhere') {
                    query.where(e as string);
                }
            }
        }
    }

    private applySearching(query: Query, search: any): void {
        // Check if a search operation is requested
        if (search && search.length > 0) {
            // Extract the search key and fields from the search array
            const { fields, key } = search[0];
            // perform search operation using the field and key on the query
            query.search(key, fields);
        }
    }

    private applySorting(query: Query, sorted: sortInfo[]): void {
        // Check if sorting data is available
        if (sorted && sorted.length > 0) {
            // Iterate through each sorting info
            sorted.forEach(sort => {
                // get the sort field name either by name or field
                const sortField = sort.name || sort.field;
                // Perform sort operation using the query based on the field name and direction
                query.sortBy(sortField as string, sort.direction);
            });
        }
    }

    private applyGrouping(query: Query, group: any): void {
        // Check if sorting data is available
        if (group.length > 0) {
            // Iterate through each group info
            group.forEach((column: string) => {
                // perform group operation using the column on the query
                query.group(column);
            });
        }
    }

    private applyLazyLoad = (query: Query, state: any) => {
        if (state.isLazyLoad) {
            // Configure lazy loading for the main data
            query.lazyLoad.push({ key: 'isLazyLoad', value: true });
            // If on-demand group loading is enabled, configure lazy loading for grouped data
            if (state.onDemandGroupInfo) {
                query.lazyLoad.push({
                    key: 'onDemandGroupInfo',
                    value: state.action.lazyLoadQuery,
                });
            }
        }
    }

    private applyPaging(query: Query, state: any) {
        // Check if both 'take' and 'skip' values are available
        if (state.take && state.skip) {
            // Calculate pageSkip and pageTake values to get pageIndex and pageSize
            const pageSkip = state.skip / state.take + 1;
            const pageTake = state.take;
            query.page(pageSkip, pageTake);
        }
        // If if only 'take' is available and 'skip' is 0, apply paging for the first page.
        else if (state.skip === 0 && state.take) {
            query.page(1, state.take);
        }
    }


    /** GET all data from the server */
    getAllData(state: any, action: any): Observable<any> {
        const query = new Query();
        // filtering
        if (state.where) {
            this.applyFiltering(query, action.queries);
        }
        // initial filtering
        if (state.filter && state.filter.columns && state.filter.columns.length) {
            this.applyFiltering(query, state.filter);
        }
        // // Checkbox/Excel filtering
        // if (action.distincts && action.distincts.length) {
        //   query.select(action.distincts);
        // }
        // search
        if (state.search) {
            this.applySearching(query, state.search);
        };
        // sorting
        if (state.sorted) {
            state.sorted.length ? this.applySorting(query, state.sorted) :
                // initial sorting
                state.sorted.columns.length ? this.applySorting(query, state.sorted.columns) : null
        }
        // grouping
        if (state.group) {
            state.group.length ? this.applyGrouping(query, state.group) :
                // initial grouping
                state.group.columns.length ? this.applyGrouping(query, state.group.columns) : null
        }
        // lazy load grouping
        this.applyLazyLoad(query, state)
        // intial grouping with lazy load
        if (state.group && state.group.enableLazyLoading) {
            query.lazyLoad.push({ key: 'isLazyLoad', value: true })
        }
        // paging
        this.applyPaging(query, state)
        // To get the count of the data
        query.isCountRequired = true

        return this.http.get<OrderDetails[]>(this.ordersUrl).pipe(
            map((response: any[]) => {
                response = (DataUtil.parse as any).parseJson(response);
                // console.log('response => ', response);
                // Checkbox/Excel filtering handling.
                if (
                    state.action &&
                    (state.action.requestType == 'filterchoicerequest' ||
                        state.action.requestType == 'filterSearchBegin' ||
                        state.action.requestType == 'stringfilterrequest')
                ) {
                    var checkboxquery: Query = new Query();
                    checkboxquery.take(state.take);
                    if (state.where && state.where.length) {
                        checkboxquery.where(
                            state.where[0].field,
                            state.where[0].operator,
                            state.where[0].value as string,
                            state.where[0].ignoreCase
                        );
                    }
                    state.dataSource(new DataManager(response).executeLocal(checkboxquery));
                    return;
                }
                // Execute local data operations using the provided query
                const currentResult: any = new DataManager(response).executeLocal(query);
                console.log('pipe => ', currentResult);
                // Return the result along with the count of total records
                return {
                    result: currentResult.result, // Result of the data
                    count: currentResult.count // Total record count
                };
            })
        );
    }

    /** POST: add a new record  to the server */
    addRecord(state: DataSourceChangedEventArgs): Observable<OrderDetails> {
        return this.http.post<OrderDetails>(this.ordersUrl, state.data, httpOptions);
    }

    /** DELETE: delete the record from the server */
    deleteRecord(state: any): Observable<OrderDetails> {
        const id = state.data[0].id;
        const url = `${this.ordersUrl}/${id}`;
        return this.http.delete<OrderDetails>(url, httpOptions);
    }

    /** PUT: update the record on the server */
    updateRecord(state: DataSourceChangedEventArgs): Observable<OrderDetails> {
        return this.http.put(this.ordersUrl, state.data, httpOptions);
    }


}