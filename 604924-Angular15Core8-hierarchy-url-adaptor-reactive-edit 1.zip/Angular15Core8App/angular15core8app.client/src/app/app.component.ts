import {
  AfterViewInit,
  Component,
  Inject,
  OnChanges,
  OnInit,
  SimpleChanges,
  TemplateRef,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import {
  DetailRowService,
  SortService,
  PageService,
  FilterService,
  GridModel,
  EditService,
  DialogEditEventArgs,
  SaveEventArgs,
  GridComponent,
  ActionEventArgs,
} from '@syncfusion/ej2-angular-grids';
import { SharedGridComponent } from './shared-grid.component';
import {
  AbstractControl,
  FormGroup,
} from '@angular/forms';
import { GridConfigService } from './grid-config.service';
import { DataUtil } from '@syncfusion/ej2-data';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  providers: [
    DetailRowService,
    SortService,
    PageService,
    FilterService,
    EditService,
  ],
})
export class AppComponent
  extends GridConfigService
  implements OnInit, AfterViewInit, OnChanges
{
  @ViewChild('hierarchygrid') public hierarchygrid?: SharedGridComponent;
  @ViewChild('parentEditSettingsTemplateRef', { static: true })
  public parentEditSettingsTemplateRef: any;
  @ViewChild('firstChildEditSettingsTemplateRef', { static: true })
  public firstChildEditSettingsTemplateRef: any;
  @ViewChild('secondChildEditSettingsTemplateRef', { static: true })
  public secondChildEditSettingsTemplateRef: any;
  constructor(
    @Inject(ViewContainerRef) private viewContainerRef?: ViewContainerRef
  ) {
    super();
  }
  public registeredTemplate = {};
  public secondLevelChildGridSettings?: GridModel;
  public firstLevelChildGridSettings?: GridModel;
  public parentGridSettings?: GridModel;
  public parentForm: FormGroup<any> = new FormGroup({});
  public firstLevelChildForm: FormGroup<any> = new FormGroup({});
  public secondLevelChildForm: FormGroup<any> = new FormGroup({});

  ngAfterViewInit() {
    this.parentEditSettingsTemplateRef.elementRef.nativeElement._viewContainerRef =
      this.viewContainerRef;
    this.parentEditSettingsTemplateRef.elementRef.nativeElement.propName =
      'editSettingsTemplate';
    this.firstChildEditSettingsTemplateRef.elementRef.nativeElement._viewContainerRef =
      this.viewContainerRef;
    this.firstChildEditSettingsTemplateRef.elementRef.nativeElement.propName =
      'firstChildEditSettingsTemplate';
    this.secondChildEditSettingsTemplateRef.elementRef.nativeElement._viewContainerRef =
      this.viewContainerRef;
    this.secondChildEditSettingsTemplateRef.elementRef.nativeElement.propName =
      'secondChildEditSettingsTemplate';
  }
  ngOnInit(): void {
    // Second level child grid settings
    this.secondLevelChildGridSettings = {
      dataSource: this.getSecondLevelChildData(),
      queryString: 'CustomerID',
      columns: this.getSecondLevelChildColumns(),
      editSettings: this.getEditSettings(
        this.secondChildEditSettingsTemplateRef
      ),
      load: function () {
        // console.log('second child load => ', this)
        (this as any).registeredTemplate = {};
        // this.editSettings_template = this.secondChildEditSettingsTemplateRef;
      },
      actionBegin: this.actionBegin.bind(this),
      actionComplete: this.actionComplete.bind(this),
    };
    // console.log(
    //   'second child grid datas => ',
    //   this.secondLevelChildGridSettings.dataSource,
    //   'second child grid columns => ',
    //   this.secondLevelChildGridSettings.columns
    // );
    // First level child grid settings
    this.firstLevelChildGridSettings = {
      dataSource: this.getFirstLevelChildData(),
      queryString: 'EmployeeID',
      pageSettings: { pageSize: 6, pageCount: 5 },
      columns: this.getFirstLevelChildColumns(),
      editSettings: this.getEditSettings(
        this.firstChildEditSettingsTemplateRef
      ),
      childGrid: this.secondLevelChildGridSettings,
      load: function () {
        // console.log('first child load => ', this)
        (this as any).registeredTemplate = {};
        // this.editSettings_template = this.firstChildEditSettingsTemplateRef;
      },
      actionBegin: this.actionBegin.bind(this),
      actionComplete: this.actionComplete.bind(this),
    };
    // console.log(
    //   'first child grid datas => ',
    //   this.firstLevelChildGridSettings.dataSource,
    //   'first child grid columns => ',
    //   this.firstLevelChildGridSettings.columns
    // );
    // Parent grid settings
    this.parentGridSettings = {
      dataSource: this.getParentGridData(),
      columns: this.getParentGridColumns(),
      editSettings: this.getEditSettings(this.parentEditSettingsTemplateRef),
      childGrid: this.firstLevelChildGridSettings,
    };
    // console.log(
    //   'parent grid datas => ',
    //   this.parentGridSettings.dataSource,
    //   'parent grid columns => ',
    //   this.parentGridSettings.columns
    // );
  }
  ngOnChanges(changes: SimpleChanges): void {
  }
  employee() {
    // console.log('employee clicked!');
    this.hierarchygrid!.grid!.columns = this.getParentGridColumns();
    this.hierarchygrid!.grid!.dataSource = this.getParentGridData();
    this.hierarchygrid!.grid!.editSettings = this.getEditSettings(this.parentEditSettingsTemplateRef);
    (this.hierarchygrid as any).grid.childGrid = undefined;
    this.hierarchygrid!.grid!.freezeRefresh();
  }
  order() {
    // console.log('order clicked!');
    this.hierarchygrid!.grid!.columns = this.getFirstLevelChildColumns();
    this.hierarchygrid!.grid!.dataSource = this.getFirstLevelChildData();
    this.hierarchygrid!.grid!.editSettings = this.getEditSettings(
      this.firstChildEditSettingsTemplateRef
    );
    (this.hierarchygrid as any).grid.childGrid = undefined;
    this.hierarchygrid!.grid!.freezeRefresh();
  }
  customer() {
    // console.log('customer clicked!');
    this.hierarchygrid!.grid!.columns = this.getSecondLevelChildColumns();
    this.hierarchygrid!.grid!.dataSource = this.getSecondLevelChildData();
    this.hierarchygrid!.grid!.editSettings = this.getEditSettings(
      this.secondChildEditSettingsTemplateRef
    );
    (this.hierarchygrid as any).grid.childGrid = undefined;
    this.hierarchygrid!.grid!.freezeRefresh();
  }
  hierarchy() {
    this.hierarchygrid!.grid!.columns = this.getParentGridColumns();
    this.hierarchygrid!.grid!.dataSource = this.getParentGridData();
    this.hierarchygrid!.grid!.editSettings = this.getEditSettings(
      this.parentEditSettingsTemplateRef
    );
    (this.hierarchygrid as any).grid.childGrid = this.firstLevelChildGridSettings;
    this.hierarchygrid!.grid?.freezeRefresh();
  }
  hierarchyLoad() {
    console.log('hierarchy load');
    (this.hierarchygrid!.grid as any).registeredTemplate = {};
  }

  actionBegin(args: ActionEventArgs): void {
    // console.log('app action begin => ', args);
    if (
      (args as any).requestType === 'beginEdit' ||
      (args as any).requestType === 'add'
    ) {
      // console.log(args.requestType + ' => ', args);
      if ((args as any)['primaryKey'][0] === 'EmployeeID') {
        this.parentForm = this.initializeParentForm((args as any).rowData);
      } else if ((args as any)['primaryKey'][0] === 'OrderID') {
        this.firstLevelChildForm = this.initializeFirstLevelChildForm(
          (args as any).rowData
        );
      } else if ((args as any)['primaryKey'][0] === 'CustomerID') {
        this.secondLevelChildForm = this.initializeSecondLevelChildForm(
          (args as any).rowData
        );
      }
    }
    if ((args as any).requestType === 'save') {
      if ((args as any)['primaryKey'][0] === 'EmployeeID') {
        if (this.parentForm!.valid) {
          (args as any).data = this.parentForm!.value;
        } else {
          (args as any).cancel = true;
        }
      } else if ((args as any)['primaryKey'][0] === 'OrderID') {
        if (this.firstLevelChildForm!.valid) {
          (args as any).data = this.firstLevelChildForm!.value;
        } else {
          (args as any).cancel = true;
        }
      } else if ((args as any)['primaryKey'][0] === 'CustomerID') {
        if (this.secondLevelChildForm!.valid) {
          (args as any).data = this.secondLevelChildForm!.value;
        } else {
          (args as any).cancel = true;
        }
      }
    }
  }

  actionComplete(args: ActionEventArgs): void {
    // console.log('app action complete => ', args);
    if (
      (args as any).requestType === 'beginEdit' ||
      (args as any).requestType === 'add'
    ) {
      // // Set initial Focus
      // if ((args as any).requestType === 'beginEdit') {
      //   (
      //     (args as any).form.elements.namedItem(
      //       'CustomerID'
      //     ) as HTMLInputElement
      //   ).focus();
      // } else if ((args as any).requestType === 'add') {
      //   (
      //     (args as any).form.elements.namedItem('OrderID') as HTMLInputElement
      //   ).focus();
      // }
      // // not defined column or not visible column
      // const formObj = (this.hierarchygrid as GridComponent).editModule.formObj;
      // const shipAddressRules = {
      //     required: true
      // };
      // if (args.requestType === 'beginEdit' || args.requestType === 'add') {
      //     // Add the custom validation rule
      //     formObj.addRules('ShipAddress', shipAddressRules);
      // }
    }
  }
  public focusIn(target: HTMLElement | any): void {
    (target as any).parentElement.classList.add('e-input-focus');
  }

  public focusOut(target: HTMLElement | any): void {
    (target as any).parentElement.classList.remove('e-input-focus');
  }

  // get EmployeeID(): AbstractControl {
  //   return this.parentForm.get('EmployeeID');
  // }

  // get FirstName(): AbstractControl {
  //   return this.parentForm.get('FirstName');
  // }

  // get Title(): AbstractControl {
  //   return this.parentForm.get('Title');
  // }

  // get HireDate(): AbstractControl {
  //   return this.parentForm.get('HireDate');
  // }

  // get ReportsTo(): AbstractControl {
  //   return this.parentForm.get('ReportsTo');
  // }

  // get OrderID(): AbstractControl {
  //   return this.firstLevelChildForm.get('OrderID');
  // }

  // get ShipCity(): AbstractControl {
  //   return this.firstLevelChildForm.get('ShipCity');
  // }

  // get Freight(): AbstractControl {
  //   return this.firstLevelChildForm.get('Freight');
  // }

  // get OrderDate(): AbstractControl {
  //   return this.firstLevelChildForm.get('OrderDate');
  // }

  // get CustomerID(): AbstractControl {
  //   return this.secondLevelChildForm.get('CustomerID');
  // }

  // get ContactName(): AbstractControl {
  //   return this.secondLevelChildForm.get('ContactName');
  // }

  // get Address(): AbstractControl {
  //   return this.secondLevelChildForm.get('Address');
  // }

  // get Country(): AbstractControl {
  //   return this.secondLevelChildForm.get('Country');
  // }
}
