import {
  AfterViewInit,
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import {
  ActionEventArgs,
  Column,
  ColumnModel,
  DataResult,
  EditSettingsModel,
  GridComponent,
  GridModel,
} from '@syncfusion/ej2-angular-grids';
import { DataManager } from '@syncfusion/ej2-data';

@Component({
  selector: 'app-shared-grid',
  templateUrl: './shared-grid.component.html',
  styleUrls: ['./shared-grid.component.css'],
})
export class SharedGridComponent implements OnInit, AfterViewInit, OnChanges {
  @ViewChild('grid') public grid?: GridComponent;
  @Input() gridData?: Object | DataManager | DataResult;
  @Input() gridColumns?: ColumnModel[] | Column[] | string[];
  @Input() childGrid?: GridModel;
  @Input() editSettings?: EditSettingsModel;
  @Input() actionBegin?: (args: ActionEventArgs) => void;
  @Input() actionComplete?: (args: ActionEventArgs) => void;
  @Input() load?: () => void;

  public gridSettings: GridModel = {};
  constructor() {}

  ngAfterViewInit() {}
  ngOnChanges(changes: SimpleChanges): void {}
  ngOnInit() {
    // console.log('gridColumn => ', this.gridColumns);
    // console.log('gridData => ', this.gridData);
    this.gridSettings = {
      dataSource: this.gridData,
      columns: this.gridColumns,
      childGrid: this.childGrid,
      editSettings: this.editSettings,
      actionBegin: this.actionBegin ? this.actionBegin : (args) => {},
      actionComplete: this.actionComplete ? this.actionComplete : (args) => {},
      load: this.load ? this.load : () => {}
    };
  }
}
