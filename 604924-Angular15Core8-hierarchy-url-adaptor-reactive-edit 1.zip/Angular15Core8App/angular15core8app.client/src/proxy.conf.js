const PROXY_CONFIG = [
  {
    context: [
      "/**" // need to config for get all api.
    ],
    target: "https://localhost:7085",
    secure: false
  }
]

module.exports = PROXY_CONFIG;
